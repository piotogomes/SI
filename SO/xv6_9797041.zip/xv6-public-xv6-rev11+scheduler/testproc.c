#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

void cpu_bound(int it)
{
    volatile long x = 0;
    for (int i = 0; i < it; i++)
    {
        for (int j = 0; j < it; j++)
        {
            x += 6 * 7;
        }
    }
    exit();
}

void io_bound(int it)
{
    int fd;
    char buffer[64];
    char filename[3];
    filename[0] = '0' + getpid() / 10;
    filename[1] = '0' + getpid() % 10;
    filename[2] = '\0';

    for (int i = 0; i < it; i++)
    {
        fd = open(filename, O_CREATE | O_RDWR);
        if (fd < 0)
        {
            printf(1, "Error opening file\n");
            exit();
        }

        write(fd, "6767676767\n", 11);
        close(fd);
        fd = open(filename, O_RDONLY);
        read(fd, buffer, sizeof(buffer));
        close(fd);

        unlink(filename);
    }
    exit();
}

int main(int argc, char *argv[])
{
    if (argc < 5)
    {
        printf(1, "Usage: testproc <#cpuBoundProc> <#iterations> <#ioBoundProc> <#iterations>\n");
        exit();
    }

    int cpuprocs = atoi(argv[1]);
    char *cpuiterations = argv[2];
    int ioprocs = atoi(argv[3]);
    char *ioiterations = argv[4];

    for (int i = 0; i < cpuprocs; i++)
    {
        int pid = fork();
        if (pid < 0)
        {
            printf(1, "Error on process %d\n", i);
            break;
        }
        if (pid == 0)
        {
            cpu_bound(atoi(cpuiterations));
            exit();
        }
    }
    for (int i = 0; i < ioprocs; i++)
    {
        int pid = fork();
        if (pid < 0)
        {
            printf(1, "Error on process %d\n", i);
            break;
        }
        if (pid == 0)
        {
            io_bound(atoi(ioiterations));
            exit();
        }
    }

    for (int i = 0; i < (cpuprocs + ioprocs); i++)
    {
        wait();
    }

    exit();
}
