#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[])
{
  if (argc < 2)
  {
    printf(1, "Usage: getprocinfo <#processes> <type> (0 = normal, 1 = csv)\n");
    exit();
  }

  int n = atoi(argv[1]);
  int type = atoi(argv[2]);

  struct proc_stat history[64];

  int count = getprocinfo(n, history);
  if (count < 0)
  {
    printf(1, "Error getting history to: %d\n", n);
  }
  else
  {
    if (type == 0)
    {
      for (int i = 0; i < count; i++)
      {
        printf(1, "  NAME(PID):  %s(%d)\n", history[i].name, history[i].pid);
        printf(1, "  RUNNING:  %d ticks\n", history[i].running_time);
        printf(1, "  RUNNABLE: %d ticks\n", history[i].runnable_time);
        printf(1, "  SLEEPING: %d ticks\n", history[i].sleeping_time);
      }
    }
    if (type == 1)
    {
      for (int i = 0; i < count; i++)
      {
        printf(1, "%d, %d, %d, %d\n", history[i].pid, history[i].running_time, history[i].runnable_time, history[i].sleeping_time);
      }
    }
  }

  exit();
}