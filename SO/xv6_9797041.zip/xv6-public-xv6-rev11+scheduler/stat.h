#define T_DIR  1   // Directory
#define T_FILE 2   // File
#define T_DEV  3   // Device

struct stat {
  short type;  // Type of file
  int dev;     // File system's disk device
  uint ino;    // Inode number
  short nlink; // Number of links to file
  uint size;   // Size of file in bytes
};

// new structs for the SYS_getprocinfo

struct proc_stat {
  int pid;
  char name[16];
  int running_time;
  int sleeping_time;
  int runnable_time;
};
